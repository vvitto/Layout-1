Thank you for downloading this font.

Font name: Existence Stencil Light
Font format: OpenType, PS-flavoured
Designer: Yeah Noah (yeahnoah@netscape.net)
Designer URL: http://mywebpage.netscape.com/yeahnoah/index.html

You can use this font at your own risk as you like.
You can freely distribute the original unmodified archive file as long 
as no money involved.

--------------------------------
End-user license agreement
--------------------------------

SOFTWARE PRODUCT LICENSE

The SOFTWARE PRODUCT is protected by copyright laws and
international copyright treaties, as well as other intellectual
property laws and treaties. The SOFTWARE PRODUCT is licensed, not
sold.

1. GRANT OF LICENSE. This document grants you the following rights:

- Installation and Use. You may install and use an unlimited number
of copies of the SOFTWARE PRODUCT.

- Reproduction and Distribution. You may reproduce and distribute an
unlimited number of copies of the SOFTWARE PRODUCT;  provided that
each copy shall be a true and complete copy, including all copyright
and trademark notices (if applicable), and shall be accompanied by a
copy of this text file. Copies of the SOFTWARE PRODUCT may not be
distributed for profit either on a standalone basis or included as
part of your own product unless by prior permission of Yeah Noah.

2. DESCRIPTION OF OTHER RIGHTS AND LIMITATIONS.

- Restrictions on Alteration.  You may not rename, edit or create
any derivative works from the SOFTWARE PRODUCT, other than
subsetting when embedding them in documents unless you have
permission from Yeah Noah.

LIMITED WARRANTY NO WARRANTIES. Yeah Noah expressly disclaims any
warranty for the SOFTWARE PRODUCT. The SOFTWARE PRODUCT and any
related documentation is provided "as is" without warranty of any
kind, either express or implied, including, without limitation, the
implied warranties or merchantability, fitness for a particular
purpose, or noninfringement. The entire risk arising out of use or
performance of the SOFTWARE PRODUCT remains with you.

NO LIABILITY FOR CONSEQUENTIAL DAMAGES. In no event shall Yeah Noah
be liable for any damages whatsoever (including, without limitation,
damages for loss of business profits, business interruption, loss of
business information, or any other pecuniary loss) arising out of
the use of or inability to use this product, even if Yeah Noah has
been advised of the possibility of such damages.
